package com.dxc.learning.personrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
